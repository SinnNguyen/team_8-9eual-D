﻿using System;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("Test completed! Press ENTER to exit..."); 
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
